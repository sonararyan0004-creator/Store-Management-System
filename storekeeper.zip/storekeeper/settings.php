<?php
require_once __DIR__ . '/includes/functions.php';
require_admin();

$keys = ['store_name', 'store_address', 'store_phone', 'currency', 'tax_percent', 'expiry_alert_days', 'receipt_footer'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($keys as $k) {
        $v = trim($_POST[$k] ?? '');
        if ($k === 'tax_percent') $v = (string)max(0, min(100, (float)$v));
        if ($k === 'expiry_alert_days') $v = (string)max(1, (int)$v);
        if ($k === 'store_name' && $v === '') $v = 'StoreKeeper';
        q('INSERT INTO settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$k, $v]);
    }
    flash('success', 'Settings saved.');
    redirect('settings.php');
}

page_header('Store Settings', 'settings');
?>
<div class="card" style="max-width:720px">
  <form method="post" class="form">
    <?= csrf_field() ?>
    <label class="field"><span>Store name</span><input name="store_name" value="<?= e(setting('store_name')) ?>" required></label>
    <label class="field"><span>Address (shown on invoices)</span><input name="store_address" value="<?= e(setting('store_address')) ?>"></label>
    <div class="row-2">
      <label class="field"><span>Phone</span><input name="store_phone" value="<?= e(setting('store_phone')) ?>"></label>
      <label class="field"><span>Currency symbol</span><input name="currency" value="<?= e(setting('currency', '₹')) ?>" maxlength="5"></label>
    </div>
    <div class="row-2">
      <label class="field"><span>Tax on bills (%)</span><input type="number" step="0.01" min="0" max="100" name="tax_percent" value="<?= e(setting('tax_percent', '0')) ?>"><small>Set 0 if your prices already include GST.</small></label>
      <label class="field"><span>Warn about expiry within (days)</span><input type="number" min="1" name="expiry_alert_days" value="<?= e(setting('expiry_alert_days', '30')) ?>"></label>
    </div>
    <label class="field"><span>Invoice footer message</span><input name="receipt_footer" value="<?= e(setting('receipt_footer')) ?>"></label>
    <div class="actions"><button class="btn btn-primary" type="submit">Save settings</button></div>
  </form>
</div>
<?php page_footer();
