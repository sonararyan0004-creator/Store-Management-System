<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

// Cancel a sale (admin): put the stock back and remove the bill
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel'])) {
    csrf_check();
    if (!is_admin()) {
        flash('error', 'Only the admin can cancel a bill.');
        redirect('sales.php');
    }
    $sid = (int)$_POST['cancel'];
    $sale = row('SELECT invoice_no FROM sales WHERE id = ?', [$sid]);
    if ($sale) {
        $pdo = db();
        try {
            $pdo->beginTransaction();
            foreach (rows('SELECT product_id, qty FROM sale_items WHERE sale_id = ? AND product_id IS NOT NULL', [$sid]) as $it) {
                stock_change((int)$it['product_id'], (float)$it['qty'], 'return', $sale['invoice_no'], 'Bill cancelled');
            }
            q('DELETE FROM sales WHERE id = ?', [$sid]);
            $pdo->commit();
            flash('success', 'Bill ' . $sale['invoice_no'] . ' cancelled and stock restored.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('error', 'Could not cancel the bill: ' . $ex->getMessage());
        }
    }
    redirect('sales.php');
}

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$term = trim($_GET['s'] ?? '');

$sql = 'SELECT s.*, c.name cname, (SELECT COUNT(*) FROM sale_items si WHERE si.sale_id = s.id) items FROM sales s LEFT JOIN customers c ON c.id = s.customer_id WHERE DATE(s.created_at) BETWEEN ? AND ?';
$params = [$from, $to];
if ($term !== '') {
    $sql .= ' AND (s.invoice_no LIKE ? OR c.name LIKE ?)';
    $params[] = "%$term%";
    $params[] = "%$term%";
}
$sql .= ' ORDER BY s.id DESC LIMIT 500';
$sales = rows($sql, $params);
$sum = array_sum(array_column($sales, 'total'));

page_header('Sales & Invoices', 'sales');
?>
<div class="card">
  <form class="toolbar" method="get">
    <label class="search"><?= icon('search') ?><input type="search" name="s" value="<?= e($term) ?>" placeholder="Invoice no. or customer"></label>
    <input type="date" name="from" value="<?= e($from) ?>"> <span class="muted">to</span> <input type="date" name="to" value="<?= e($to) ?>">
    <button class="btn" type="submit">Filter</button>
    <span style="flex:1"></span>
    <span class="muted"><?= count($sales) ?> bills · <b><?= e(money($sum)) ?></b></span>
    <a class="btn btn-primary" href="pos.php"><?= icon('plus') ?> New sale</a>
  </form>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th class="r">Items</th><th>Payment</th><th class="r">Total</th><th class="r">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($sales as $s): ?>
        <tr>
          <td><a href="invoice.php?id=<?= (int)$s['id'] ?>"><b><?= e($s['invoice_no']) ?></b></a></td>
          <td><?= e(fdate($s['created_at'], 'd M Y, h:i A')) ?></td>
          <td><?= e($s['cname'] ?: 'Walk-in') ?></td>
          <td class="r"><?= (int)$s['items'] ?></td>
          <td><span class="badge badge-blue"><?= e(strtoupper($s['payment_method'])) ?></span></td>
          <td class="r"><b><?= e(money($s['total'])) ?></b></td>
          <td class="r nowrap">
            <a class="btn btn-sm" href="invoice.php?id=<?= (int)$s['id'] ?>" title="View"><?= icon('eye') ?></a>
            <?php if (is_admin()): ?>
            <form method="post" class="inline" data-confirm="Cancel this bill and put the items back in stock?">
              <?= csrf_field() ?><input type="hidden" name="cancel" value="<?= (int)$s['id'] ?>">
              <button class="btn btn-sm btn-danger" title="Cancel bill"><?= icon('trash') ?></button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$sales): ?><tr><td colspan="7" class="empty">No bills in this period.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php page_footer();
