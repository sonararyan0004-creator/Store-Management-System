<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    csrf_check();
    if (!is_admin()) {
        flash('error', 'Only the admin can delete products.');
    } else {
        q('DELETE FROM products WHERE id = ?', [(int)$_POST['delete']]);
        flash('success', 'Product deleted (past bills keep their item names).');
    }
    redirect('products.php');
}

$cat = (int)($_GET['cat'] ?? 0);
$filter = $_GET['f'] ?? '';
$sql = 'SELECT p.*, c.name cname FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE 1=1';
$params = [];
if ($cat) { $sql .= ' AND p.category_id = ?'; $params[] = $cat; }
if ($filter === 'low') $sql .= ' AND p.stock > 0 AND p.stock <= p.reorder_level';
if ($filter === 'out') $sql .= ' AND p.stock <= 0';
$sql .= ' ORDER BY p.name';
$products = rows($sql, $params);
$cats = rows('SELECT id, name FROM categories ORDER BY name');

page_header('Products', 'products');
?>
<div class="card">
  <div class="card-head">
    <form class="toolbar" style="margin:0" method="get">
      <label class="search"><?= icon('search') ?><input type="search" placeholder="Search name or SKU…" data-filter="#ptable"></label>
      <select name="cat" onchange="this.form.submit()">
        <option value="0">All categories</option>
        <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $cat === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select>
      <select name="f" onchange="this.form.submit()">
        <option value="">Any stock level</option>
        <option value="low" <?= $filter === 'low' ? 'selected' : '' ?>>Low stock</option>
        <option value="out" <?= $filter === 'out' ? 'selected' : '' ?>>Out of stock</option>
      </select>
    </form>
    <a class="btn btn-primary" href="product_form.php"><?= icon('plus') ?> Add product</a>
  </div>
  <div class="table-wrap">
    <table id="ptable">
      <thead><tr><th>Product</th><th>Category</th><th class="r">Cost</th><th class="r">Price</th><th class="r">Stock</th><th>Status</th><th>Expiry</th><th class="r">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($products as $p): ?>
        <tr>
          <td class="pname"><b><?= e($p['name']) ?></b><small><?= e($p['sku']) ?></small></td>
          <td><?= e($p['cname'] ?: '—') ?></td>
          <td class="r"><?= e(money($p['cost_price'])) ?></td>
          <td class="r"><b><?= e(money($p['sell_price'])) ?></b></td>
          <td class="r"><?= e(qty($p['stock'])) ?> <small><?= e($p['unit']) ?></small></td>
          <td><?= stock_badge($p) ?></td>
          <td><?= expiry_badge($p['expiry_date']) ?></td>
          <td class="r nowrap">
            <a class="btn btn-sm" href="product_form.php?id=<?= (int)$p['id'] ?>" title="Edit"><?= icon('edit') ?></a>
            <?php if (is_admin()): ?>
            <form method="post" class="inline" data-confirm="Delete <?= e($p['name']) ?>?">
              <?= csrf_field() ?><input type="hidden" name="delete" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-sm btn-danger" title="Delete"><?= icon('trash') ?></button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$products): ?><tr><td colspan="8" class="empty">No products found. <a href="product_form.php">Add your first product</a>.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php page_footer();
