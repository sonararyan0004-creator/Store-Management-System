<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$view = (int)($_GET['view'] ?? 0);

if ($view) {
    $pu = row('SELECT p.*, s.name sname, u.name uname FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id LEFT JOIN users u ON u.id = p.user_id WHERE p.id = ?', [$view]);
    if (!$pu) { flash('error', 'Purchase not found.'); redirect('purchases.php'); }
    $items = rows('SELECT * FROM purchase_items WHERE purchase_id = ? ORDER BY id', [$view]);
    page_header('Purchase #' . $pu['id'], 'purchases');
    ?>
    <div class="actions no-print" style="margin-bottom:16px"><a class="btn" href="purchases.php">← Back</a><button class="btn" onclick="window.print()"><?= icon('printer') ?> Print</button></div>
    <div class="card invoice">
      <div class="invoice-head">
        <div><h2>Stock-in #<?= (int)$pu['id'] ?></h2><div class="muted">Supplier: <b><?= e($pu['sname'] ?: '—') ?></b><br>Reference: <?= e($pu['reference'] ?: '—') ?></div></div>
        <div class="inv-meta"><b><?= e(fdate($pu['purchase_date'])) ?></b><br><span class="muted">Entered by <?= e($pu['uname'] ?: '—') ?></span></div>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Cost</th><th class="r">Amount</th></tr></thead>
        <tbody><?php foreach ($items as $it): ?><tr><td><?= e($it['name']) ?></td><td class="r"><?= e(qty($it['qty'])) ?></td><td class="r"><?= e(money($it['cost'])) ?></td><td class="r"><?= e(money($it['total'])) ?></td></tr><?php endforeach; ?></tbody>
        <tfoot><tr><td colspan="3" class="r">Total</td><td class="r"><?= e(money($pu['total'])) ?></td></tr></tfoot>
      </table></div>
      <?php if ($pu['note']): ?><p class="muted">Note: <?= e($pu['note']) ?></p><?php endif; ?>
    </div>
    <?php
    page_footer();
    exit;
}

$list = rows('SELECT p.*, s.name sname, (SELECT COUNT(*) FROM purchase_items i WHERE i.purchase_id = p.id) items FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id ORDER BY p.id DESC LIMIT 200');
page_header('Stock In / Purchases', 'purchases');
?>
<div class="card">
  <div class="card-head">
    <h3>Purchase history <span class="muted">(<?= count($list) ?>)</span></h3>
    <a class="btn btn-primary" href="purchase_form.php"><?= icon('plus') ?> Receive new stock</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Date</th><th>Supplier</th><th>Reference</th><th class="r">Items</th><th class="r">Total</th><th class="r"></th></tr></thead>
      <tbody>
      <?php foreach ($list as $p): ?>
        <tr>
          <td><?= (int)$p['id'] ?></td>
          <td><?= e(fdate($p['purchase_date'])) ?></td>
          <td><?= e($p['sname'] ?: '—') ?></td>
          <td><?= e($p['reference'] ?: '—') ?></td>
          <td class="r"><?= (int)$p['items'] ?></td>
          <td class="r"><b><?= e(money($p['total'])) ?></b></td>
          <td class="r"><a class="btn btn-sm" href="purchases.php?view=<?= (int)$p['id'] ?>" title="View"><?= icon('eye') ?></a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$list): ?><tr><td colspan="7" class="empty">No stock received yet. <a href="purchase_form.php">Receive your first delivery</a>.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php page_footer();
