<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$sale = row('SELECT s.*, c.name cname, c.phone cphone, u.name uname FROM sales s LEFT JOIN customers c ON c.id = s.customer_id LEFT JOIN users u ON u.id = s.user_id WHERE s.id = ?', [$id]);
if (!$sale) { flash('error', 'Invoice not found.'); redirect('sales.php'); }
$items = rows('SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id', [$id]);

page_header('Invoice ' . $sale['invoice_no'], 'sales');
?>
<div class="no-print actions" style="margin-bottom:16px">
  <button class="btn btn-primary" onclick="window.print()"><?= icon('printer') ?> Print</button>
  <a class="btn" href="pos.php"><?= icon('cart') ?> New sale</a>
  <a class="btn" href="sales.php">All sales</a>
</div>
<div class="card invoice">
  <div class="invoice-head">
    <div>
      <h2><?= e(setting('store_name')) ?></h2>
      <div class="muted"><?= e(setting('store_address')) ?><br><?= e(setting('store_phone')) ?></div>
    </div>
    <div class="inv-meta">
      <h2>INVOICE</h2>
      <b><?= e($sale['invoice_no']) ?></b><br>
      <span class="muted"><?= e(fdate($sale['created_at'], 'd M Y, h:i A')) ?></span><br>
      <span class="badge badge-blue"><?= e(strtoupper($sale['payment_method'])) ?></span>
    </div>
  </div>
  <p><span class="muted">Billed to:</span> <b><?= e($sale['cname'] ?: 'Walk-in customer') ?></b> <?= $sale['cphone'] ? '· ' . e($sale['cphone']) : '' ?>
     &nbsp;·&nbsp; <span class="muted">Cashier:</span> <?= e($sale['uname'] ?: '—') ?></p>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Item</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Amount</th></tr></thead>
      <tbody>
      <?php foreach ($items as $i => $it): ?>
        <tr><td><?= $i + 1 ?></td><td><?= e($it['name']) ?></td><td class="r"><?= e(qty($it['qty'])) ?></td><td class="r"><?= e(money($it['price'])) ?></td><td class="r"><?= e(money($it['total'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><td colspan="4" class="r muted">Subtotal</td><td class="r"><?= e(money($sale['subtotal'])) ?></td></tr>
        <?php if ((float)$sale['discount'] > 0): ?><tr><td colspan="4" class="r muted">Discount</td><td class="r">−<?= e(money($sale['discount'])) ?></td></tr><?php endif; ?>
        <?php if ((float)$sale['tax'] > 0): ?><tr><td colspan="4" class="r muted">Tax</td><td class="r"><?= e(money($sale['tax'])) ?></td></tr><?php endif; ?>
        <tr><td colspan="4" class="r" style="font-size:18px">Total</td><td class="r" style="font-size:18px"><?= e(money($sale['total'])) ?></td></tr>
      </tfoot>
    </table>
  </div>
  <p class="muted" style="text-align:center;margin-top:24px"><?= e(setting('receipt_footer')) ?></p>
</div>
<?php page_footer();
