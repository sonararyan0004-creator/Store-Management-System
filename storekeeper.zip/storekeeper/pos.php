<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$taxPercent = (float)setting('tax_percent', '0');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $cart = json_decode($_POST['cart'] ?? '[]', true);
    $customerId = (int)($_POST['customer_id'] ?? 0) ?: null;
    $method = in_array($_POST['payment_method'] ?? '', ['cash', 'upi', 'card', 'credit'], true) ? $_POST['payment_method'] : 'cash';
    $discount = max(0, (float)($_POST['discount'] ?? 0));

    if (!is_array($cart) || !$cart) {
        flash('error', 'The cart is empty.');
        redirect('pos.php');
    }

    $pdo = db();
    try {
        $pdo->beginTransaction();
        $lines = [];
        $subtotal = 0.0;
        foreach ($cart as $item) {
            $pid = (int)($item['id'] ?? 0);
            $qty = (float)($item['qty'] ?? 0);
            if ($pid <= 0 || $qty <= 0) continue;
            $p = row('SELECT id, name, cost_price, sell_price, stock, unit FROM products WHERE id = ? FOR UPDATE', [$pid]);
            if (!$p) throw new RuntimeException('A product in the cart no longer exists.');
            if ($qty > (float)$p['stock']) {
                throw new RuntimeException($p['name'] . ': only ' . qty($p['stock']) . ' ' . $p['unit'] . ' in stock.');
            }
            $lineTotal = round($qty * (float)$p['sell_price'], 2);
            $subtotal += $lineTotal;
            $lines[] = [$p, $qty, $lineTotal];
        }
        if (!$lines) throw new RuntimeException('The cart is empty.');

        $discount = min($discount, $subtotal);
        $tax = round(($subtotal - $discount) * $taxPercent / 100, 2);
        $total = round($subtotal - $discount + $tax, 2);

        $next = (int)val('SELECT COALESCE(MAX(id),0) + 1 FROM sales');
        $invoice = 'INV-' . date('Ymd') . '-' . str_pad((string)$next, 4, '0', STR_PAD_LEFT);

        q('INSERT INTO sales (invoice_no, customer_id, user_id, subtotal, discount, tax, total, payment_method) VALUES (?,?,?,?,?,?,?,?)',
          [$invoice, $customerId, current_user()['id'], $subtotal, $discount, $tax, $total, $method]);
        $saleId = (int)$pdo->lastInsertId();

        foreach ($lines as [$p, $qtyLine, $lineTotal]) {
            q('INSERT INTO sale_items (sale_id, product_id, name, qty, price, cost, total) VALUES (?,?,?,?,?,?,?)',
              [$saleId, $p['id'], $p['name'], $qtyLine, $p['sell_price'], $p['cost_price'], $lineTotal]);
            stock_change((int)$p['id'], -$qtyLine, 'sale', $invoice, 'POS sale');
        }
        $pdo->commit();
        flash('success', "Bill $invoice saved.");
        redirect('invoice.php?id=' . $saleId . '&new=1');
    } catch (RuntimeException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $ex->getMessage());
        redirect('pos.php');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
}

$products = rows('SELECT p.id, p.sku, p.name, p.sell_price AS price, p.stock, p.unit, p.category_id AS cat FROM products p ORDER BY p.name');
foreach ($products as &$pp) {
    $pp['id'] = (int)$pp['id'];
    $pp['price'] = (float)$pp['price'];
    $pp['stock'] = (float)$pp['stock'];
    $pp['cat'] = (int)$pp['cat'];
}
unset($pp);
$cats = rows('SELECT id, name FROM categories ORDER BY name');
$customers = rows('SELECT id, name, phone FROM customers ORDER BY name');
$cfg = ['products' => $products, 'currency' => setting('currency', '₹'), 'tax' => $taxPercent];

page_header('New Sale', 'pos');
?>
<div class="pos">
  <div class="card">
    <div class="toolbar">
      <label class="search" style="flex:1"><?= icon('search') ?><input id="q" type="search" placeholder="Search product or scan barcode, press Enter…" autofocus autocomplete="off"></label>
    </div>
    <div class="chips" id="chips">
      <button type="button" class="chip on" data-cat="0">All</button>
      <?php foreach ($cats as $c): ?><button type="button" class="chip" data-cat="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></button><?php endforeach; ?>
    </div>
    <div class="pos-products" id="grid"></div>
  </div>

  <form class="card cart" method="post" id="checkout">
    <?= csrf_field() ?>
    <input type="hidden" name="cart" id="cartField">
    <input type="hidden" name="discount" id="discountField" value="0">
    <div class="card-head"><h3>Current bill</h3><button type="button" class="btn btn-sm btn-danger" id="clear">Clear</button></div>
    <div class="cart-items" id="cartItems"></div>

    <div class="totals">
      <div><span class="muted">Subtotal</span><b id="subtotal">0.00</b></div>
      <div><span class="muted">Discount</span><input type="number" id="discount" min="0" step="0.01" value="0"></div>
      <div><span class="muted">Tax (<?= e(qty($taxPercent)) ?>%)</span><b id="tax">0.00</b></div>
      <div class="grand"><span>Total</span><span id="total">0.00</span></div>
    </div>

    <div class="row-2" style="margin-bottom:14px">
      <label class="field"><span>Customer</span>
        <select name="customer_id"><option value="">Walk-in customer</option>
          <?php foreach ($customers as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name'] . ($c['phone'] ? ' · ' . $c['phone'] : '')) ?></option><?php endforeach; ?>
        </select></label>
      <label class="field"><span>Payment</span>
        <select name="payment_method"><option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option><option value="credit">Credit (pay later)</option></select></label>
    </div>
    <button class="btn btn-primary btn-lg" type="submit" id="payBtn"><?= icon('cart') ?> Complete sale</button>
  </form>
</div>

<script>
(function () {
  var CFG = <?= json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
  var cart = {};          // id -> qty
  var catFilter = 0;
  var byId = {};
  CFG.products.forEach(function (p) { byId[p.id] = p; });

  var $ = function (id) { return document.getElementById(id); };
  var money = function (n) { return CFG.currency + n.toFixed(2); };
  var esc = function (s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; };
  var fmtQty = function (n) { return String(parseFloat(n.toFixed(3))); };

  function renderGrid() {
    var term = $('q').value.trim().toLowerCase();
    var html = '';
    CFG.products.forEach(function (p) {
      if (catFilter && p.cat !== catFilter) return;
      if (term && (p.name + ' ' + p.sku).toLowerCase().indexOf(term) === -1) return;
      var out = p.stock <= 0;
      html += '<button type="button" class="pcard' + (out ? ' out' : '') + '" data-id="' + p.id + '"' + (out ? ' disabled' : '') + '>' +
        '<b>' + esc(p.name) + '</b><span class="price">' + money(p.price) + ' <small>/ ' + esc(p.unit) + '</small></span>' +
        '<small>' + (out ? 'Out of stock' : fmtQty(p.stock) + ' in stock') + '</small></button>';
    });
    $('grid').innerHTML = html || '<p class="muted">No matching products.</p>';
  }

  function renderCart() {
    var ids = Object.keys(cart), sub = 0, html = '';
    ids.forEach(function (id) {
      var p = byId[id], q = cart[id], line = p.price * q;
      sub += line;
      html += '<div class="cart-line"><div><b>' + esc(p.name) + '</b><br><small>' + money(p.price) + ' / ' + esc(p.unit) + '</small></div>' +
        '<div class="qty"><button type="button" data-act="dec" data-id="' + id + '">−</button>' +
        '<input type="number" step="any" min="0" value="' + fmtQty(q) + '" data-act="set" data-id="' + id + '">' +
        '<button type="button" data-act="inc" data-id="' + id + '">+</button></div>' +
        '<b>' + money(line) + '</b></div>';
    });
    $('cartItems').innerHTML = html || '<div class="empty-cart">Tap a product to add it to the bill</div>';
    var disc = Math.min(Math.max(parseFloat($('discount').value) || 0, 0), sub);
    var tax = (sub - disc) * CFG.tax / 100;
    $('subtotal').textContent = money(sub);
    $('tax').textContent = money(tax);
    $('total').textContent = money(sub - disc + tax);
    $('payBtn').disabled = !ids.length;
  }

  function add(id, n) {
    var p = byId[id]; if (!p || p.stock <= 0) return;
    var next = (cart[id] || 0) + n;
    if (next > p.stock) { next = p.stock; alert('Only ' + fmtQty(p.stock) + ' ' + p.unit + ' of ' + p.name + ' in stock.'); }
    if (next <= 0) delete cart[id]; else cart[id] = next;
    renderCart();
  }

  $('grid').addEventListener('click', function (e) {
    var b = e.target.closest('.pcard'); if (b) add(b.getAttribute('data-id'), 1);
  });
  $('cartItems').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-act]'); if (!b) return;
    add(b.getAttribute('data-id'), b.getAttribute('data-act') === 'inc' ? 1 : -1);
  });
  $('cartItems').addEventListener('change', function (e) {
    var i = e.target; if (i.getAttribute('data-act') !== 'set') return;
    var id = i.getAttribute('data-id'), v = parseFloat(i.value) || 0, p = byId[id];
    if (v > p.stock) { v = p.stock; alert('Only ' + fmtQty(p.stock) + ' ' + p.unit + ' in stock.'); }
    if (v <= 0) delete cart[id]; else cart[id] = v;
    renderCart();
  });
  $('chips').addEventListener('click', function (e) {
    var c = e.target.closest('.chip'); if (!c) return;
    document.querySelectorAll('.chip').forEach(function (x) { x.classList.remove('on'); });
    c.classList.add('on'); catFilter = parseInt(c.getAttribute('data-cat'), 10); renderGrid();
  });
  $('q').addEventListener('input', renderGrid);
  $('q').addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    var t = $('q').value.trim().toLowerCase(); if (!t) return;
    var exact = CFG.products.filter(function (p) { return p.sku.toLowerCase() === t; })[0];
    var hits = exact ? [exact] : CFG.products.filter(function (p) { return p.stock > 0 && p.name.toLowerCase().indexOf(t) > -1; });
    if (hits.length === 1 || exact) { add(String(hits[0].id), 1); $('q').value = ''; renderGrid(); }
  });
  $('discount').addEventListener('input', renderCart);
  $('clear').addEventListener('click', function () { cart = {}; $('discount').value = 0; renderCart(); });
  $('checkout').addEventListener('submit', function (e) {
    var arr = Object.keys(cart).map(function (id) { return { id: parseInt(id, 10), qty: cart[id] }; });
    if (!arr.length) { e.preventDefault(); return; }
    $('cartField').value = JSON.stringify(arr);
    $('discountField').value = $('discount').value || 0;
  });

  renderGrid(); renderCart();
})();
</script>
<?php page_footer();
