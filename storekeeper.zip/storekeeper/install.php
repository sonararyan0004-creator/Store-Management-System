<?php
// One-click installer: creates the database, tables, demo logins and (optionally) sample grocery data.
// Open http://localhost/storekeeper/install.php once. You can delete this file afterwards.
require_once __DIR__ . '/config.php';

$done = false;
$error = '';
$withSample = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $withSample = !empty($_POST['sample']);
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo->exec('USE `' . DB_NAME . '`');

        $sql = file_get_contents(__DIR__ . '/database.sql');
        $sql = preg_replace('/^--.*$/m', '', $sql);
        foreach (preg_split('/;\s*[\r\n]+/', $sql) as $stmt) {
            $stmt = trim($stmt);
            if ($stmt === '') continue;
            // skip the CREATE DATABASE / USE lines, we already handled them using config.php
            if (stripos($stmt, 'CREATE DATABASE') === 0 || stripos($stmt, 'USE ') === 0) continue;
            $pdo->exec($stmt);
        }

        if ($withSample) seed_sample($pdo);
        $done = true;
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

function seed_sample(PDO $pdo): void {
    $cats = ['Fruits & Vegetables', 'Dairy & Eggs', 'Bakery', 'Staples & Grains', 'Snacks', 'Beverages', 'Household', 'Personal Care'];
    $st = $pdo->prepare('INSERT INTO categories (name, description) VALUES (?, ?)');
    foreach ($cats as $c) $st->execute([$c, '']);

    $sups = [
        ['Fresh Farm Traders', '9822011101', 'fresh@farm.example', 'APMC Market, Pune'],
        ['Amul Distributors', '9822011102', 'sales@dairy.example', 'Hadapsar, Pune'],
        ['Sai Wholesale Mart', '9822011103', 'sai@wholesale.example', 'Bhosari, Pune'],
        ['Metro Beverages', '9822011104', 'orders@bev.example', 'Kothrud, Pune'],
    ];
    $st = $pdo->prepare('INSERT INTO suppliers (name, phone, email, address) VALUES (?,?,?,?)');
    foreach ($sups as $s) $st->execute($s);

    // name, category#, supplier#, unit, cost, price, stock, reorder, expiry days (null = none)
    $products = [
        ['Tomato', 1, 1, 'kg', 22, 32, 40, 10, 6], ['Onion', 1, 1, 'kg', 24, 34, 55, 15, 30], ['Potato', 1, 1, 'kg', 20, 28, 60, 15, 30],
        ['Banana', 1, 1, 'dozen', 40, 60, 18, 6, 5], ['Apple (Shimla)', 1, 1, 'kg', 120, 160, 22, 8, 12], ['Coriander Bunch', 1, 1, 'pcs', 6, 10, 4, 10, 3],
        ['Full Cream Milk 1L', 2, 2, 'pack', 56, 66, 48, 20, 4], ['Curd 400g', 2, 2, 'pack', 28, 38, 26, 10, 9], ['Paneer 200g', 2, 2, 'pack', 70, 90, 12, 6, 10],
        ['Eggs (tray of 6)', 2, 2, 'pack', 36, 48, 30, 10, 14], ['Salted Butter 100g', 2, 2, 'pack', 52, 62, 3, 8, 90],
        ['Sandwich Bread', 3, 3, 'pack', 28, 40, 20, 8, 5], ['Pav (6 pcs)', 3, 3, 'pack', 18, 26, 14, 8, 2], ['Tea Biscuits', 3, 3, 'pack', 8, 12, 70, 20, 120],
        ['Basmati Rice 5kg', 4, 3, 'bag', 480, 590, 14, 5, 300], ['Wheat Flour 5kg', 4, 3, 'bag', 215, 260, 20, 6, 150], ['Toor Dal 1kg', 4, 3, 'pack', 135, 165, 25, 8, 280],
        ['Sugar 1kg', 4, 3, 'pack', 42, 52, 40, 12, 365], ['Iodised Salt 1kg', 4, 3, 'pack', 18, 25, 36, 10, 500], ['Sunflower Oil 1L', 4, 3, 'bottle', 120, 148, 0, 10, 240],
        ['Potato Chips 52g', 5, 3, 'pack', 16, 20, 80, 20, 100], ['Namkeen Mix 200g', 5, 3, 'pack', 38, 50, 33, 10, 90], ['Chocolate Bar', 5, 3, 'pcs', 32, 45, 45, 15, 200],
        ['Cola 750ml', 6, 4, 'bottle', 30, 40, 36, 12, 150], ['Orange Juice 1L', 6, 4, 'pack', 70, 95, 15, 6, 60], ['Tea Powder 500g', 6, 3, 'pack', 190, 235, 18, 6, 240],
        ['Mineral Water 1L', 6, 4, 'bottle', 12, 20, 90, 30, 365], ['Dish Wash Liquid', 7, 3, 'bottle', 80, 105, 16, 6, null], ['Detergent Powder 1kg', 7, 3, 'pack', 95, 125, 22, 8, null],
        ['Toilet Cleaner', 7, 3, 'bottle', 78, 99, 9, 5, null], ['Bathing Soap', 8, 3, 'pcs', 28, 38, 60, 20, null], ['Toothpaste 150g', 8, 3, 'pack', 72, 95, 28, 10, null],
        ['Shampoo Sachet', 8, 3, 'pcs', 1.5, 2, 4, 40, null],
    ];
    $st = $pdo->prepare('INSERT INTO products (sku, name, category_id, supplier_id, unit, cost_price, sell_price, stock, reorder_level, expiry_date) VALUES (?,?,?,?,?,?,?,?,?,?)');
    foreach ($products as $i => $p) {
        $exp = $p[8] === null ? null : date('Y-m-d', strtotime('+' . $p[8] . ' day'));
        $st->execute(['SK' . str_pad((string)($i + 1), 4, '0', STR_PAD_LEFT), $p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $p[6], $p[7], $exp]);
    }

    $customers = [['Rahul Sharma', '9876500001'], ['Priya Patil', '9876500002'], ['Amit Deshmukh', '9876500003'], ['Sneha Kulkarni', '9876500004']];
    $st = $pdo->prepare('INSERT INTO customers (name, phone) VALUES (?, ?)');
    foreach ($customers as $c) $st->execute($c);

    // fake sales for the last 14 days so the dashboard has something to show
    $prods = $pdo->query('SELECT id, name, cost_price, sell_price FROM products WHERE stock > 0')->fetchAll(PDO::FETCH_ASSOC);
    $insSale = $pdo->prepare('INSERT INTO sales (invoice_no, customer_id, user_id, subtotal, discount, tax, total, payment_method, created_at) VALUES (?,?,?,?,?,?,?,?,?)');
    $insItem = $pdo->prepare('INSERT INTO sale_items (sale_id, product_id, name, qty, price, cost, total) VALUES (?,?,?,?,?,?,?)');
    $methods = ['cash', 'upi', 'card', 'cash', 'upi'];
    mt_srand(42);
    $n = 1;
    for ($d = 13; $d >= 0; $d--) {
        $bills = mt_rand(4, 9);
        for ($b = 0; $b < $bills; $b++) {
            $when = date('Y-m-d H:i:s', strtotime("-$d day 09:00:00") + mt_rand(0, 12 * 3600));
            $lines = [];
            $sub = 0;
            foreach ((array)array_rand($prods, mt_rand(2, 5)) as $k) {
                $pr = $prods[$k];
                $q = mt_rand(1, 3);
                $lines[] = [$pr, $q];
                $sub += $q * $pr['sell_price'];
            }
            $invoice = 'INV-' . date('Ymd', strtotime($when)) . '-' . str_pad((string)$n++, 4, '0', STR_PAD_LEFT);
            $cust = mt_rand(0, 2) === 0 ? mt_rand(1, 4) : null;
            $insSale->execute([$invoice, $cust, 1, $sub, 0, 0, $sub, $methods[array_rand($methods)], $when]);
            $sid = (int)$pdo->lastInsertId();
            foreach ($lines as [$pr, $q]) {
                $insItem->execute([$sid, $pr['id'], $pr['name'], $q, $pr['sell_price'], $pr['cost_price'], $q * $pr['sell_price']]);
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Install StoreKeeper</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="display:grid;place-items:center;min-height:100vh;padding:20px">
<div class="card" style="max-width:520px;width:100%">
  <div class="brand-mark" style="color:#fff;margin-bottom:14px"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l1-5h16l1 5"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/><path d="M5 12v8h14v-8"/></svg></div>
  <h2>StoreKeeper installer</h2>
  <?php if ($done): ?>
    <div class="flash flash-success" style="margin-top:16px">Installed successfully! The database <b><?= htmlspecialchars(DB_NAME) ?></b> is ready.</div>
    <p>Sign in with <b>admin</b> / <b>admin123</b> (or <b>staff</b> / <b>staff123</b>).</p>
    <a class="btn btn-primary btn-lg" href="login.php">Go to login</a>
    <p class="muted" style="font-size:13px">For safety, delete <code>install.php</code> once you are done — running it again wipes all data.</p>
  <?php else: ?>
    <p class="muted">This creates the <b><?= htmlspecialchars(DB_NAME) ?></b> database and all tables in your XAMPP MySQL.<br><b style="color:var(--danger)">Warning:</b> if the database already exists, its StoreKeeper tables are reset.</p>
    <?php if ($error): ?><div class="flash flash-error"><?= htmlspecialchars($error) ?><br><small>Check that MySQL is started in XAMPP and that config.php has the right user/password.</small></div><?php endif; ?>
    <form method="post" class="form">
      <label style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="sample" value="1" style="width:auto" <?= $withSample ? 'checked' : '' ?>> Load sample grocery data (products, customers and 2 weeks of sales)</label>
      <button class="btn btn-primary btn-lg" type="submit" onclick="return confirm('Create / reset the database now?')">Install now</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>
