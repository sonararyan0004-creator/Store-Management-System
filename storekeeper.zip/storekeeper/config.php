<?php
// ---------------------------------------------------------------
// StoreKeeper configuration
// XAMPP defaults: user "root", empty password.
// ---------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'storekeeper');

date_default_timezone_set('Asia/Kolkata');
