<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$p = $id ? row('SELECT * FROM products WHERE id = ?', [$id]) : null;
if ($id && !$p) { flash('error', 'Product not found.'); redirect('products.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? '');
    $sku = trim($_POST['sku'] ?? '');
    $catId = (int)($_POST['category_id'] ?? 0) ?: null;
    $supId = (int)($_POST['supplier_id'] ?? 0) ?: null;
    $unit = trim($_POST['unit'] ?? 'pcs') ?: 'pcs';
    $cost = max(0, (float)($_POST['cost_price'] ?? 0));
    $sell = max(0, (float)($_POST['sell_price'] ?? 0));
    $reorder = max(0, (float)($_POST['reorder_level'] ?? 0));
    $expiry = trim($_POST['expiry_date'] ?? '') ?: null;

    if ($name === '') {
        flash('error', 'Product name is required.');
        redirect('product_form.php' . ($id ? "?id=$id" : ''));
    }
    if ($sku === '') $sku = 'P' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
    $dup = val('SELECT COUNT(*) FROM products WHERE sku = ? AND id <> ?', [$sku, $id]);
    if ($dup) {
        flash('error', 'That SKU / barcode is already used by another product.');
        redirect('product_form.php' . ($id ? "?id=$id" : ''));
    }

    if ($id) {
        q('UPDATE products SET sku=?, name=?, category_id=?, supplier_id=?, unit=?, cost_price=?, sell_price=?, reorder_level=?, expiry_date=? WHERE id=?',
          [$sku, $name, $catId, $supId, $unit, $cost, $sell, $reorder, $expiry, $id]);
        flash('success', 'Product updated.');
    } else {
        $stock = max(0, (float)($_POST['stock'] ?? 0));
        q('INSERT INTO products (sku, name, category_id, supplier_id, unit, cost_price, sell_price, stock, reorder_level, expiry_date) VALUES (?,?,?,?,?,?,?,?,?,?)',
          [$sku, $name, $catId, $supId, $unit, $cost, $sell, 0, $reorder, $expiry]);
        $newId = (int)db()->lastInsertId();
        if ($stock > 0) stock_change($newId, $stock, 'opening', '', 'Opening stock');
        flash('success', 'Product added.');
    }
    redirect('products.php');
}

$cats = rows('SELECT id, name FROM categories ORDER BY name');
$sups = rows('SELECT id, name FROM suppliers ORDER BY name');
$units = ['pcs', 'kg', 'g', 'litre', 'ml', 'pack', 'box', 'dozen', 'bottle', 'bag'];
$v = fn($k, $d = '') => e($p[$k] ?? $d);

page_header($p ? 'Edit product' : 'Add product', 'products');
?>
<div class="card" style="max-width:820px">
  <form method="post" class="form">
    <?= csrf_field() ?>
    <div class="row-2">
      <label class="field"><span>Product name *</span><input name="name" value="<?= $v('name') ?>" required autofocus></label>
      <label class="field"><span>SKU / barcode (auto if empty)</span><input name="sku" value="<?= $v('sku') ?>"></label>
    </div>
    <div class="row-2">
      <label class="field"><span>Category</span>
        <select name="category_id"><option value="">— none —</option>
          <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)($p['category_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select></label>
      <label class="field"><span>Supplier</span>
        <select name="supplier_id"><option value="">— none —</option>
          <?php foreach ($sups as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)($p['supplier_id'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
        </select></label>
    </div>
    <div class="row-3">
      <label class="field"><span>Unit</span>
        <select name="unit"><?php foreach ($units as $u): ?><option <?= ($p['unit'] ?? 'pcs') === $u ? 'selected' : '' ?>><?= e($u) ?></option><?php endforeach; ?></select></label>
      <label class="field"><span>Cost price</span><input type="number" step="0.01" min="0" name="cost_price" value="<?= $v('cost_price', '0') ?>"></label>
      <label class="field"><span>Selling price *</span><input type="number" step="0.01" min="0" name="sell_price" value="<?= $v('sell_price', '0') ?>" required></label>
    </div>
    <div class="row-3">
      <?php if (!$p): ?>
        <label class="field"><span>Opening stock</span><input type="number" step="0.001" min="0" name="stock" value="0"></label>
      <?php else: ?>
        <label class="field"><span>Current stock</span><input value="<?= e(qty($p['stock'])) ?>" disabled><small>Change it from Stock Control or Stock In.</small></label>
      <?php endif; ?>
      <label class="field"><span>Low-stock alert at</span><input type="number" step="0.001" min="0" name="reorder_level" value="<?= $v('reorder_level', '5') ?>"></label>
      <label class="field"><span>Expiry date</span><input type="date" name="expiry_date" value="<?= $v('expiry_date') ?>"></label>
    </div>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Save product</button>
      <a class="btn" href="products.php">Cancel</a>
    </div>
  </form>
</div>
<?php page_footer();
