<?php
require_once __DIR__ . '/includes/functions.php';

crud_page([
    'table' => 'suppliers',
    'title' => 'Suppliers',
    'singular' => 'Supplier',
    'active' => 'suppliers',
    'fields' => [
        'name' => ['label' => 'Supplier name', 'required' => true],
        'phone' => ['label' => 'Phone', 'type' => 'tel'],
        'email' => ['label' => 'Email', 'type' => 'email'],
        'address' => ['label' => 'Address'],
    ],
    'columns' => [
        'name' => ['Name'],
        'phone' => ['Phone'],
        'email' => ['Email'],
        'items' => ['Products', 'num'],
        'bought' => ['Total purchased', 'money'],
    ],
    'list_sql' => 'SELECT s.*, (SELECT COUNT(*) FROM products p WHERE p.supplier_id = s.id) AS items, (SELECT COALESCE(SUM(total),0) FROM purchases pu WHERE pu.supplier_id = s.id) AS bought FROM suppliers s ORDER BY s.name',
]);
