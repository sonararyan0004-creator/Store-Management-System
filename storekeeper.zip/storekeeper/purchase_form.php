<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $supId = (int)($_POST['supplier_id'] ?? 0) ?: null;
    $ref = trim($_POST['reference'] ?? '');
    $date = trim($_POST['purchase_date'] ?? '') ?: date('Y-m-d');
    $note = trim($_POST['note'] ?? '');
    $updateCost = !empty($_POST['update_cost']);
    $pids = $_POST['product_id'] ?? [];
    $qtys = $_POST['qty'] ?? [];
    $costs = $_POST['cost'] ?? [];

    $lines = [];
    foreach ($pids as $i => $pid) {
        $pid = (int)$pid;
        $qt = (float)($qtys[$i] ?? 0);
        $cost = (float)($costs[$i] ?? 0);
        if ($pid > 0 && $qt > 0 && $cost >= 0) $lines[] = [$pid, $qt, $cost];
    }
    if (!$lines) {
        flash('error', 'Add at least one product with a quantity.');
        redirect('purchase_form.php');
    }

    $pdo = db();
    try {
        $pdo->beginTransaction();
        $total = 0.0;
        foreach ($lines as $l) $total += round($l[1] * $l[2], 2);
        q('INSERT INTO purchases (supplier_id, reference, total, note, user_id, purchase_date) VALUES (?,?,?,?,?,?)',
          [$supId, $ref, $total, $note, current_user()['id'], $date]);
        $puId = (int)$pdo->lastInsertId();
        foreach ($lines as [$pid, $qt, $cost]) {
            $p = row('SELECT id, name FROM products WHERE id = ?', [$pid]);
            if (!$p) throw new RuntimeException('A selected product no longer exists.');
            q('INSERT INTO purchase_items (purchase_id, product_id, name, qty, cost, total) VALUES (?,?,?,?,?,?)',
              [$puId, $pid, $p['name'], $qt, $cost, round($qt * $cost, 2)]);
            stock_change($pid, $qt, 'purchase', '#' . $puId, $ref);
            if ($updateCost) q('UPDATE products SET cost_price = ? WHERE id = ?', [$cost, $pid]);
        }
        $pdo->commit();
        flash('success', 'Stock received: ' . count($lines) . ' item(s), total ' . money($total) . '.');
        redirect('purchases.php');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', 'Could not save: ' . $ex->getMessage());
        redirect('purchase_form.php');
    }
}

$products = rows('SELECT id, name, unit, cost_price FROM products ORDER BY name');
$sups = rows('SELECT id, name FROM suppliers ORDER BY name');
$pjson = array_map(fn($p) => ['id' => (int)$p['id'], 'name' => $p['name'], 'unit' => $p['unit'], 'cost' => (float)$p['cost_price']], $products);

page_header('Receive Stock', 'purchases');
?>
<form method="post" class="card" id="pform" style="max-width:980px">
  <?= csrf_field() ?>
  <div class="row-3" style="margin-bottom:16px">
    <label class="field"><span>Supplier</span>
      <select name="supplier_id"><option value="">— none —</option>
        <?php foreach ($sups as $s): ?><option value="<?= (int)$s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?>
      </select></label>
    <label class="field"><span>Bill / reference no.</span><input name="reference" maxlength="60"></label>
    <label class="field"><span>Date received</span><input type="date" name="purchase_date" value="<?= e(date('Y-m-d')) ?>"></label>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th style="width:44%">Product</th><th class="r">Quantity</th><th class="r">Cost / unit</th><th class="r">Amount</th><th></th></tr></thead>
      <tbody id="lines"></tbody>
      <tfoot><tr><td colspan="3" class="r">Total</td><td class="r" id="grand">0.00</td><td></td></tr></tfoot>
    </table>
  </div>
  <button type="button" class="btn" id="addLine" style="margin:12px 0"><?= icon('plus') ?> Add another product</button>

  <label class="field" style="margin-bottom:12px"><span>Note (optional)</span><input name="note" maxlength="200"></label>
  <label style="display:flex;gap:10px;align-items:center;margin-bottom:16px"><input type="checkbox" name="update_cost" value="1" checked style="width:auto"> Update each product's cost price to this purchase cost</label>
  <div class="actions"><button class="btn btn-primary" type="submit">Save &amp; add to stock</button><a class="btn" href="purchases.php">Cancel</a></div>
</form>

<script>
(function () {
  var P = <?= json_encode($pjson, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
  var CUR = <?= json_encode(setting('currency', '₹'), JSON_UNESCAPED_UNICODE) ?>;
  var body = document.getElementById('lines');
  var opts = '<option value="">Choose product…</option>' + P.map(function (p) {
    return '<option value="' + p.id + '" data-cost="' + p.cost + '">' + p.name.replace(/&/g, '&amp;').replace(/</g, '&lt;') + ' (' + p.unit + ')</option>';
  }).join('');

  function addLine() {
    var tr = document.createElement('tr');
    tr.innerHTML = '<td><select name="product_id[]">' + opts + '</select></td>' +
      '<td><input type="number" name="qty[]" step="0.001" min="0" class="r" value=""></td>' +
      '<td><input type="number" name="cost[]" step="0.01" min="0" class="r" value=""></td>' +
      '<td class="r amt">0.00</td>' +
      '<td class="r"><button type="button" class="btn btn-sm btn-danger rm" title="Remove">✕</button></td>';
    body.appendChild(tr);
  }
  function recalc() {
    var g = 0;
    body.querySelectorAll('tr').forEach(function (tr) {
      var q = parseFloat(tr.querySelector('[name="qty[]"]').value) || 0;
      var c = parseFloat(tr.querySelector('[name="cost[]"]').value) || 0;
      tr.querySelector('.amt').textContent = (q * c).toFixed(2);
      g += q * c;
    });
    document.getElementById('grand').textContent = CUR + g.toFixed(2);
  }
  body.addEventListener('change', function (e) {
    if (e.target.tagName === 'SELECT') {
      var o = e.target.options[e.target.selectedIndex];
      var cost = e.target.closest('tr').querySelector('[name="cost[]"]');
      if (o && o.getAttribute('data-cost') && !cost.value) cost.value = o.getAttribute('data-cost');
    }
    recalc();
  });
  body.addEventListener('input', recalc);
  body.addEventListener('click', function (e) {
    if (e.target.closest('.rm')) { e.target.closest('tr').remove(); if (!body.children.length) addLine(); recalc(); }
  });
  document.getElementById('addLine').addEventListener('click', addLine);
  addLine(); addLine();
})();
</script>
<?php page_footer();
