<?php
require_once __DIR__ . '/../config.php';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
            $pdo->exec("SET time_zone = '+05:30'");
        } catch (PDOException $e) {
            http_response_code(500);
            echo '<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;max-width:560px;margin:80px auto;padding:0 20px">'
               . '<h2>Database not ready</h2>'
               . '<p>Make sure <b>Apache</b> and <b>MySQL</b> are running in XAMPP, then run the installer once:</p>'
               . '<p><a href="install.php" style="background:#16a34a;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Open installer</a></p>'
               . '<p style="color:#666;font-size:14px">Details: ' . htmlspecialchars($e->getMessage()) . '</p></body>';
            exit;
        }
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement {
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}
function row(string $sql, array $params = []) { return q($sql, $params)->fetch(); }
function rows(string $sql, array $params = []): array { return q($sql, $params)->fetchAll(); }
function val(string $sql, array $params = []) { return q($sql, $params)->fetchColumn(); }
