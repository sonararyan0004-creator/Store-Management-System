<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/db.php';

/* ---------- basic helpers ---------- */
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

function setting(string $key, string $default = ''): string {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (rows('SELECT k, v FROM settings') as $r) {
            $cache[$r['k']] = $r['v'];
        }
    }
    return $cache[$key] ?? $default;
}

function money($n): string {
    return setting('currency', '₹') . number_format((float)$n, 2);
}

function qty($n): string {
    // 5.000 -> 5 ; 2.500 -> 2.5
    $s = rtrim(rtrim(number_format((float)$n, 3, '.', ''), '0'), '.');
    return $s === '' ? '0' : $s;
}

function fdate($d, string $fmt = 'd M Y'): string {
    return $d ? date($fmt, strtotime($d)) : '—';
}

/* ---------- flash messages ---------- */
function flash(string $type, string $msg): void {
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}
function flash_render(): string {
    if (empty($_SESSION['flash'])) return '';
    $out = '';
    foreach ($_SESSION['flash'] as $f) {
        $out .= '<div class="flash flash-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

/* ---------- CSRF ---------- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
function csrf_check(): void {
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
    if (!$ok) {
        http_response_code(403);
        exit('Security token expired. Go back, refresh the page and try again.');
    }
}

/* ---------- auth ---------- */
function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}
function require_login(): void {
    if (!current_user()) redirect('login.php');
}
function is_admin(): bool {
    return (current_user()['role'] ?? '') === 'admin';
}
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        flash('error', 'Only the admin can open that page.');
        redirect('index.php');
    }
}

/* ---------- stock helper ---------- */
function stock_change(int $productId, float $delta, string $type, string $ref = '', string $note = ''): void {
    q('UPDATE products SET stock = stock + ? WHERE id = ?', [$delta, $productId]);
    q('INSERT INTO stock_log (product_id, change_qty, type, ref, note, user_id) VALUES (?,?,?,?,?,?)',
      [$productId, $delta, $type, $ref, $note, current_user()['id'] ?? null]);
}

function stock_badge(array $p): string {
    if ((float)$p['stock'] <= 0) return '<span class="badge badge-red">Out of stock</span>';
    if ((float)$p['stock'] <= (float)$p['reorder_level']) return '<span class="badge badge-amber">Low stock</span>';
    return '<span class="badge badge-green">In stock</span>';
}

function expiry_badge(?string $date): string {
    if (!$date) return '<span class="muted">—</span>';
    $days = (int)floor((strtotime($date) - strtotime(date('Y-m-d'))) / 86400);
    $label = fdate($date);
    if ($days < 0)  return '<span class="badge badge-red">Expired ' . e($label) . '</span>';
    if ($days <= (int)setting('expiry_alert_days', '30')) return '<span class="badge badge-amber">' . e($label) . ' (' . $days . 'd)</span>';
    return e($label);
}

/* ---------- icons (feather style) ---------- */
function icon(string $name): string {
    static $p = [
        'home' => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'cart' => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
        'box' => '<path d="M16.5 9.4L7.5 4.2M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.7z"/><polyline points="3.3 7 12 12 20.7 7"/><line x1="12" y1="22" x2="12" y2="12"/>',
        'tag' => '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
        'truck' => '<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
        'users' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
        'user' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'file' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
        'chart' => '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>',
        'sliders' => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
        'layers' => '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
        'plus' => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'minus' => '<line x1="5" y1="12" x2="19" y2="12"/>',
        'trash' => '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m5 0V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2"/>',
        'edit' => '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'menu' => '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
        'moon' => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
        'alert' => '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
        'printer' => '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
        'eye' => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
        'rupee' => '<path d="M6 3h12M6 8h12M6 13l8.5 8M6 13h3a4 4 0 0 0 0-8"/>',
        'store' => '<path d="M3 9l1-5h16l1 5"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/><path d="M5 12v8h14v-8"/>',
    ];
    return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($p[$name] ?? '') . '</svg>';
}

/* ---------- generic CRUD page (categories, suppliers, customers) ---------- */
function crud_page(array $c): void {
    require_login();
    $t = $c['table'];
    $self = basename($_SERVER['PHP_SELF']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        if (isset($_POST['delete'])) {
            $id = (int)$_POST['delete'];
            $used = !empty($c['usage_sql']) ? (int)val($c['usage_sql'], [$id]) : 0;
            if ($used > 0) {
                flash('error', "Cannot delete: it is still used by $used product(s).");
            } else {
                q("DELETE FROM `$t` WHERE id = ?", [$id]);
                flash('success', $c['singular'] . ' deleted.');
            }
            redirect($self);
        }
        $id = (int)($_POST['id'] ?? 0);
        $vals = [];
        foreach ($c['fields'] as $k => $f) {
            $vals[$k] = trim($_POST[$k] ?? '');
            if (!empty($f['required']) && $vals[$k] === '') {
                flash('error', $f['label'] . ' is required.');
                redirect($self . ($id ? "?edit=$id" : ''));
            }
        }
        if ($id) {
            $set = implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($vals)));
            q("UPDATE `$t` SET $set WHERE id = ?", array_merge(array_values($vals), [$id]));
            flash('success', $c['singular'] . ' updated.');
        } else {
            $cols = implode(', ', array_map(fn($k) => "`$k`", array_keys($vals)));
            $ph = implode(', ', array_fill(0, count($vals), '?'));
            q("INSERT INTO `$t` ($cols) VALUES ($ph)", array_values($vals));
            flash('success', $c['singular'] . ' added.');
        }
        redirect($self);
    }

    $edit = isset($_GET['edit']) ? row("SELECT * FROM `$t` WHERE id = ?", [(int)$_GET['edit']]) : null;
    $list = rows($c['list_sql']);

    page_header($c['title'], $c['active']);
    ?>
    <div class="split">
      <div class="card">
        <h3><?= $edit ? 'Edit ' . e($c['singular']) : 'Add ' . e($c['singular']) ?></h3>
        <form method="post" class="form">
          <?= csrf_field() ?>
          <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
          <?php foreach ($c['fields'] as $k => $f): ?>
            <label class="field">
              <span><?= e($f['label']) ?><?= !empty($f['required']) ? ' *' : '' ?></span>
              <input type="<?= e($f['type'] ?? 'text') ?>" name="<?= e($k) ?>" value="<?= e($edit[$k] ?? '') ?>" <?= !empty($f['required']) ? 'required' : '' ?>>
            </label>
          <?php endforeach; ?>
          <div class="actions">
            <button class="btn btn-primary" type="submit"><?= icon('plus') ?> <?= $edit ? 'Save changes' : 'Add' ?></button>
            <?php if ($edit): ?><a class="btn" href="<?= e($self) ?>">Cancel</a><?php endif; ?>
          </div>
        </form>
      </div>

      <div class="card">
        <div class="card-head">
          <h3><?= e($c['title']) ?> <span class="muted">(<?= count($list) ?>)</span></h3>
          <label class="search"><?= icon('search') ?><input type="search" placeholder="Search…" data-filter="#crud-table"></label>
        </div>
        <div class="table-wrap">
          <table id="crud-table">
            <thead><tr>
              <?php foreach ($c['columns'] as $col): ?><th class="<?= ($col[1] ?? '') === 'money' || ($col[1] ?? '') === 'num' ? 'r' : '' ?>"><?= e($col[0]) ?></th><?php endforeach; ?>
              <th class="r">Actions</th>
            </tr></thead>
            <tbody>
            <?php foreach ($list as $r): ?>
              <tr>
                <?php foreach ($c['columns'] as $key => $col): $fmt = $col[1] ?? ''; ?>
                  <td class="<?= $fmt === 'money' || $fmt === 'num' ? 'r' : '' ?>">
                    <?= $fmt === 'money' ? e(money($r[$key])) : e($r[$key] === '' ? '—' : $r[$key]) ?>
                  </td>
                <?php endforeach; ?>
                <td class="r nowrap">
                  <a class="btn btn-sm" href="<?= e($self) ?>?edit=<?= (int)$r['id'] ?>" title="Edit"><?= icon('edit') ?></a>
                  <form method="post" class="inline" data-confirm="Delete this <?= e(strtolower($c['singular'])) ?>?">
                    <?= csrf_field() ?><input type="hidden" name="delete" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-danger" title="Delete"><?= icon('trash') ?></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$list): ?><tr><td colspan="<?= count($c['columns']) + 1 ?>" class="empty">Nothing here yet.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php
    page_footer();
}

/* ---------- layout ---------- */
function page_header(string $title, string $active = ''): void {
    $u = current_user();
    $nav = [
        ['index.php', 'home', 'Dashboard', 'dashboard'],
        ['pos.php', 'cart', 'New Sale (POS)', 'pos'],
        ['sales.php', 'file', 'Sales & Invoices', 'sales'],
        ['_h', 'Inventory'],
        ['products.php', 'box', 'Products', 'products'],
        ['categories.php', 'tag', 'Categories', 'categories'],
        ['stock.php', 'layers', 'Stock Control', 'stock'],
        ['purchases.php', 'download', 'Stock In / Purchases', 'purchases'],
        ['_h', 'People'],
        ['suppliers.php', 'truck', 'Suppliers', 'suppliers'],
        ['customers.php', 'users', 'Customers', 'customers'],
        ['_h', 'Insights'],
        ['reports.php', 'chart', 'Reports', 'reports'],
    ];
    if (is_admin()) {
        $nav[] = ['_h', 'Admin'];
        $nav[] = ['users.php', 'user', 'Staff Accounts', 'users'];
        $nav[] = ['settings.php', 'sliders', 'Store Settings', 'settings'];
    }
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · <?= e(setting('store_name', 'StoreKeeper')) ?></title>
<script>try{var t=localStorage.getItem('sk-theme');if(t)document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="index.php"><span class="brand-mark"><?= icon('store') ?></span><span><b><?= e(setting('store_name', 'StoreKeeper')) ?></b><small>Store management</small></span></a>
    <nav>
      <?php foreach ($nav as $n): ?>
        <?php if ($n[0] === '_h'): ?>
          <div class="nav-head"><?= e($n[1]) ?></div>
        <?php else: ?>
          <a href="<?= e($n[0]) ?>" class="<?= $active === $n[3] ? 'active' : '' ?>"><?= icon($n[1]) ?><span><?= e($n[2]) ?></span></a>
        <?php endif; ?>
      <?php endforeach; ?>
    </nav>
  </aside>
  <div class="scrim" id="scrim"></div>
  <div class="main">
    <header class="topbar">
      <button class="icon-btn menu-btn" id="menuBtn" aria-label="Menu"><?= icon('menu') ?></button>
      <h1><?= e($title) ?></h1>
      <div class="top-actions">
        <a class="btn btn-primary hide-sm" href="pos.php"><?= icon('cart') ?> New sale</a>
        <button class="icon-btn" id="themeBtn" aria-label="Toggle dark mode"><?= icon('moon') ?></button>
        <div class="user-chip">
          <span class="avatar"><?= e(strtoupper(substr($u['name'] ?? 'U', 0, 1))) ?></span>
          <span class="hide-sm"><b><?= e($u['name'] ?? '') ?></b><small><?= e(ucfirst($u['role'] ?? '')) ?></small></span>
        </div>
        <a class="icon-btn" href="profile.php" title="My account"><?= icon('user') ?></a>
        <a class="icon-btn" href="logout.php" title="Log out"><?= icon('logout') ?></a>
      </div>
    </header>
    <main class="content">
      <?= flash_render() ?>
<?php
}

function page_footer(): void {
    ?>
    </main>
  </div>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
<?php
}
