<?php
require_once __DIR__ . '/includes/functions.php';

if (current_user()) redirect('index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $user = row('SELECT * FROM users WHERE username = ?', [$username]);
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$user['id'], 'name' => $user['name'], 'username' => $user['username'], 'role' => $user['role']];
        redirect('index.php');
    }
    $error = 'Wrong username or password.';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in · <?= e(setting('store_name', 'StoreKeeper')) ?></title>
<script>try{var t=localStorage.getItem('sk-theme');if(t)document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-wrap">
  <section class="login-art">
    <div class="brand-mark"><?= icon('store') ?></div>
    <h2>Run your grocery store with confidence.</h2>
    <p>Billing, stock, suppliers and reports in one simple place.</p>
    <ul>
      <li>Fast billing counter with printable invoices</li>
      <li>Low-stock and expiry alerts</li>
      <li>Daily sales, profit and top-seller reports</li>
    </ul>
  </section>
  <section class="login-form">
    <div class="login-card">
      <h1>Welcome back</h1>
      <p class="muted" style="margin:0 0 20px">Sign in to <?= e(setting('store_name', 'StoreKeeper')) ?></p>
      <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post" class="form">
        <?= csrf_field() ?>
        <label class="field"><span>Username</span><input name="username" autofocus required autocomplete="username"></label>
        <label class="field"><span>Password</span><input type="password" name="password" required autocomplete="current-password"></label>
        <button class="btn btn-primary btn-lg" type="submit">Sign in</button>
      </form>
      <div class="hint">Demo logins — admin / <b>admin123</b> &nbsp;·&nbsp; staff / <b>staff123</b><br>Change these in Staff Accounts after your first login.</div>
    </div>
  </section>
</div>
</body>
</html>
