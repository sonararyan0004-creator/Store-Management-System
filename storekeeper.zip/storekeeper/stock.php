<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $pid = (int)($_POST['product_id'] ?? 0);
    $dir = ($_POST['direction'] ?? 'add') === 'remove' ? -1 : 1;
    $amount = (float)($_POST['qty'] ?? 0);
    $reason = trim($_POST['reason'] ?? 'Correction');
    $note = trim($_POST['note'] ?? '');
    $p = row('SELECT id, name, stock, unit FROM products WHERE id = ?', [$pid]);

    if (!$p || $amount <= 0) {
        flash('error', 'Choose a product and enter a quantity greater than zero.');
    } elseif ($dir < 0 && $amount > (float)$p['stock']) {
        flash('error', 'You can remove at most ' . qty($p['stock']) . ' ' . $p['unit'] . ' of ' . $p['name'] . '.');
    } else {
        stock_change($pid, $dir * $amount, 'adjust', $reason, $note);
        flash('success', $p['name'] . ': stock ' . ($dir > 0 ? 'increased' : 'reduced') . ' by ' . qty($amount) . ' ' . $p['unit'] . '.');
    }
    redirect('stock.php');
}

$products = rows('SELECT id, name, sku, stock, unit, reorder_level FROM products ORDER BY name');
$low = array_filter($products, fn($p) => (float)$p['stock'] <= (float)$p['reorder_level']);
$log = rows('SELECT l.*, p.name pname, p.unit, u.name uname FROM stock_log l JOIN products p ON p.id = l.product_id LEFT JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 60');
$sel = (int)($_GET['product'] ?? 0);
$typeBadge = ['sale' => 'badge-blue', 'purchase' => 'badge-green', 'adjust' => 'badge-amber', 'return' => 'badge-green', 'opening' => 'badge-green'];

page_header('Stock Control', 'stock');
?>
<div class="split">
  <div class="grid" style="gap:18px">
    <div class="card">
      <h3>Adjust stock</h3>
      <form method="post" class="form">
        <?= csrf_field() ?>
        <label class="field"><span>Product</span>
          <select name="product_id" required>
            <option value="">Choose…</option>
            <?php foreach ($products as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $sel === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= e(qty($p['stock'])) ?> <?= e($p['unit']) ?>)</option><?php endforeach; ?>
          </select></label>
        <div class="row-2">
          <label class="field"><span>Action</span><select name="direction"><option value="add">Add stock</option><option value="remove">Remove stock</option></select></label>
          <label class="field"><span>Quantity</span><input type="number" name="qty" step="0.001" min="0.001" required></label>
        </div>
        <label class="field"><span>Reason</span>
          <select name="reason"><option>Stock count correction</option><option>Damaged</option><option>Expired</option><option>Lost / theft</option><option>Customer return</option><option>Other</option></select></label>
        <label class="field"><span>Note (optional)</span><input name="note" maxlength="200"></label>
        <button class="btn btn-primary" type="submit">Update stock</button>
      </form>
    </div>
    <div class="card">
      <div class="card-head"><h3>Needs restocking</h3><a href="purchase_form.php">Stock in →</a></div>
      <?php foreach ($low as $p): ?>
        <div class="list-row">
          <span><?= e($p['name']) ?><br><small>Alert at <?= e(qty($p['reorder_level'])) ?> <?= e($p['unit']) ?></small></span>
          <span><?= (float)$p['stock'] <= 0 ? '<span class="badge badge-red">Out</span>' : '<span class="badge badge-amber">' . e(qty($p['stock'])) . ' ' . e($p['unit']) . '</span>' ?></span>
        </div>
      <?php endforeach; ?>
      <?php if (!$low): ?><p class="muted">Everything is above its alert level.</p><?php endif; ?>
    </div>
  </div>

  <div class="card">
    <h3>Recent stock movements</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>When</th><th>Product</th><th>Type</th><th class="r">Change</th><th>Details</th><th>By</th></tr></thead>
        <tbody>
        <?php foreach ($log as $l): $neg = (float)$l['change_qty'] < 0; ?>
          <tr>
            <td class="nowrap"><?= e(fdate($l['created_at'], 'd M, h:i A')) ?></td>
            <td><?= e($l['pname']) ?></td>
            <td><span class="badge <?= e($typeBadge[$l['type']] ?? 'badge-blue') ?>"><?= e(ucfirst($l['type'])) ?></span></td>
            <td class="r" style="color:var(<?= $neg ? '--danger' : '--primary-d' ?>);font-weight:700"><?= $neg ? '' : '+' ?><?= e(qty($l['change_qty'])) ?> <small><?= e($l['unit']) ?></small></td>
            <td><small><?= e(trim($l['ref'] . ' ' . $l['note'])) ?></small></td>
            <td><small><?= e($l['uname'] ?: '—') ?></small></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$log): ?><tr><td colspan="6" class="empty">No stock movements yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php page_footer();
