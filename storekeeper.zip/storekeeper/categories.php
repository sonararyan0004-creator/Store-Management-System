<?php
require_once __DIR__ . '/includes/functions.php';

crud_page([
    'table' => 'categories',
    'title' => 'Categories',
    'singular' => 'Category',
    'active' => 'categories',
    'fields' => [
        'name' => ['label' => 'Name', 'required' => true],
        'description' => ['label' => 'Description'],
    ],
    'columns' => [
        'name' => ['Name'],
        'description' => ['Description'],
        'items' => ['Products', 'num'],
    ],
    'list_sql' => 'SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS items FROM categories c ORDER BY c.name',
    'usage_sql' => 'SELECT COUNT(*) FROM products WHERE category_id = ?',
]);
