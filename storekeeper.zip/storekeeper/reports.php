<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$range = [$from, $to];

// CSV export
if (($_GET['export'] ?? '') === 'sales') {
    $data = rows('SELECT s.invoice_no, s.created_at, COALESCE(c.name, "Walk-in") customer, s.payment_method, s.subtotal, s.discount, s.tax, s.total FROM sales s LEFT JOIN customers c ON c.id = s.customer_id WHERE DATE(s.created_at) BETWEEN ? AND ? ORDER BY s.id', $range);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="sales_' . $from . '_to_' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Invoice', 'Date', 'Customer', 'Payment', 'Subtotal', 'Discount', 'Tax', 'Total']);
    foreach ($data as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}
if (($_GET['export'] ?? '') === 'stock') {
    $data = rows('SELECT p.sku, p.name, COALESCE(c.name,"") category, p.unit, p.cost_price, p.sell_price, p.stock, p.reorder_level, p.expiry_date FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.name');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="stock_' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['SKU', 'Product', 'Category', 'Unit', 'Cost', 'Price', 'Stock', 'Alert level', 'Expiry']);
    foreach ($data as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}

$sum = row('SELECT COUNT(*) bills, COALESCE(SUM(subtotal),0) subtotal, COALESCE(SUM(discount),0) discount, COALESCE(SUM(tax),0) tax, COALESCE(SUM(total),0) total FROM sales WHERE DATE(created_at) BETWEEN ? AND ?', $range);
$cost = (float)val('SELECT COALESCE(SUM(si.qty * si.cost),0) FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE DATE(s.created_at) BETWEEN ? AND ?', $range);
$profit = (float)$sum['subtotal'] - (float)$sum['discount'] - $cost;
$avg = $sum['bills'] ? $sum['total'] / $sum['bills'] : 0;

$daily = rows('SELECT DATE(created_at) d, COUNT(*) bills, SUM(total) total FROM sales WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY d DESC', $range);
$topProducts = rows('SELECT si.name, SUM(si.qty) q, SUM(si.total) t, SUM(si.total - si.qty * si.cost) profit FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE DATE(s.created_at) BETWEEN ? AND ? GROUP BY si.name ORDER BY t DESC LIMIT 10', $range);
$byCat = rows('SELECT COALESCE(c.name, "Uncategorised") name, SUM(si.total) t FROM sale_items si JOIN sales s ON s.id = si.sale_id LEFT JOIN products p ON p.id = si.product_id LEFT JOIN categories c ON c.id = p.category_id WHERE DATE(s.created_at) BETWEEN ? AND ? GROUP BY c.name ORDER BY t DESC', $range);
$byPay = rows('SELECT payment_method m, COUNT(*) n, SUM(total) t FROM sales WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY payment_method ORDER BY t DESC', $range);
$catMax = $byCat ? (float)$byCat[0]['t'] : 1;
$stockValue = (float)val('SELECT COALESCE(SUM(stock * cost_price),0) FROM products');
$retailValue = (float)val('SELECT COALESCE(SUM(stock * sell_price),0) FROM products');

page_header('Reports', 'reports');
?>
<form class="toolbar card" method="get" style="padding:14px 16px">
  <b>Period</b>
  <input type="date" name="from" value="<?= e($from) ?>"> <span class="muted">to</span> <input type="date" name="to" value="<?= e($to) ?>">
  <button class="btn btn-primary" type="submit">Apply</button>
  <span style="flex:1"></span>
  <a class="btn" href="reports.php?export=sales&from=<?= e($from) ?>&to=<?= e($to) ?>"><?= icon('download') ?> Sales CSV</a>
  <a class="btn" href="reports.php?export=stock"><?= icon('download') ?> Stock CSV</a>
</form>

<div class="grid g-4 mt">
  <div class="card stat"><div class="bubble"><?= icon('rupee') ?></div><div><small>Revenue</small><b><?= e(money($sum['total'])) ?></b><em><?= (int)$sum['bills'] ?> bills · avg <?= e(money($avg)) ?></em></div></div>
  <div class="card stat blue"><div class="bubble"><?= icon('chart') ?></div><div><small>Gross profit</small><b><?= e(money($profit)) ?></b><em>Cost of goods <?= e(money($cost)) ?></em></div></div>
  <div class="card stat amber"><div class="bubble"><?= icon('tag') ?></div><div><small>Discounts given</small><b><?= e(money($sum['discount'])) ?></b><em>Tax collected <?= e(money($sum['tax'])) ?></em></div></div>
  <div class="card stat"><div class="bubble"><?= icon('box') ?></div><div><small>Stock value (now)</small><b><?= e(money($stockValue)) ?></b><em>At retail <?= e(money($retailValue)) ?></em></div></div>
</div>

<div class="grid g-2 mt">
  <div class="card">
    <h3>Top products</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Product</th><th class="r">Qty</th><th class="r">Sales</th><th class="r">Profit</th></tr></thead>
      <tbody>
      <?php foreach ($topProducts as $t): ?><tr><td><?= e($t['name']) ?></td><td class="r"><?= e(qty($t['q'])) ?></td><td class="r"><?= e(money($t['t'])) ?></td><td class="r"><?= e(money($t['profit'])) ?></td></tr><?php endforeach; ?>
      <?php if (!$topProducts): ?><tr><td colspan="4" class="empty">No sales in this period.</td></tr><?php endif; ?>
      </tbody></table></div>
  </div>
  <div class="card">
    <h3>Sales by category</h3>
    <?php foreach ($byCat as $c): ?>
      <div style="margin-bottom:12px">
        <div class="list-row" style="border:0;padding:0 0 4px"><span><?= e($c['name']) ?></span><b><?= e(money($c['t'])) ?></b></div>
        <div class="hbar"><i style="width:<?= round($c['t'] / $catMax * 100) ?>%"></i></div>
      </div>
    <?php endforeach; ?>
    <?php if (!$byCat): ?><p class="muted">No data.</p><?php endif; ?>
    <h3 style="margin-top:22px">Payment methods</h3>
    <?php foreach ($byPay as $m): ?>
      <div class="list-row"><span class="badge badge-blue"><?= e(strtoupper($m['m'])) ?></span><span class="muted"><?= (int)$m['n'] ?> bills</span><b><?= e(money($m['t'])) ?></b></div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card mt">
  <h3>Day-by-day sales</h3>
  <div class="table-wrap"><table>
    <thead><tr><th>Date</th><th class="r">Bills</th><th class="r">Sales</th></tr></thead>
    <tbody>
    <?php foreach ($daily as $d): ?><tr><td><?= e(fdate($d['d'], 'D, d M Y')) ?></td><td class="r"><?= (int)$d['bills'] ?></td><td class="r"><b><?= e(money($d['total'])) ?></b></td></tr><?php endforeach; ?>
    <?php if (!$daily): ?><tr><td colspan="3" class="empty">No sales in this period.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?php page_footer();
