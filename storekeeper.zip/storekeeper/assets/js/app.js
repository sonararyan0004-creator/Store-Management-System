(function () {
  // Dark mode
  var themeBtn = document.getElementById('themeBtn');
  if (themeBtn) themeBtn.addEventListener('click', function () {
    var root = document.documentElement;
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('sk-theme', next); } catch (e) {}
  });

  // Mobile sidebar
  var sb = document.getElementById('sidebar'), scrim = document.getElementById('scrim'), mb = document.getElementById('menuBtn');
  function toggle(open) {
    if (!sb) return;
    sb.classList.toggle('open', open);
    scrim.classList.toggle('open', open);
  }
  if (mb) mb.addEventListener('click', function () { toggle(!sb.classList.contains('open')); });
  if (scrim) scrim.addEventListener('click', function () { toggle(false); });

  // Confirm before submit
  document.addEventListener('submit', function (ev) {
    var msg = ev.target.getAttribute && ev.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) ev.preventDefault();
  });

  // Live table filter: <input data-filter="#tableId">
  document.querySelectorAll('[data-filter]').forEach(function (inp) {
    inp.addEventListener('input', function () {
      var t = document.querySelector(inp.getAttribute('data-filter'));
      if (!t) return;
      var term = inp.value.toLowerCase();
      t.querySelectorAll('tbody tr').forEach(function (tr) {
        tr.style.display = tr.textContent.toLowerCase().indexOf(term) > -1 ? '' : 'none';
      });
    });
  });

  // Auto-hide flash messages
  setTimeout(function () {
    document.querySelectorAll('.flash').forEach(function (f) { f.style.transition = 'opacity .5s'; f.style.opacity = '0'; setTimeout(function () { f.remove(); }, 600); });
  }, 5000);
})();
