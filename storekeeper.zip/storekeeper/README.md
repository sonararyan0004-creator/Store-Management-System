# StoreKeeper – Grocery Store Management (PHP + MySQL)

Billing counter (POS), inventory, suppliers, customers, stock-in, reports and staff logins.
Built for **XAMPP** – no Composer, no Node, no internet needed.

## Run it on XAMPP (5 steps)

1. Open the **XAMPP Control Panel** and click **Start** next to **Apache** and **MySQL**.
2. Copy this whole `storekeeper` folder into XAMPP's `htdocs` folder  
   (Windows: `C:\xampp\htdocs\storekeeper`).
3. In your browser open **http://localhost/storekeeper/install.php** and click **Install now**  
   (this creates the `storekeeper` database, tables, demo logins and optional sample data).
4. Open **http://localhost/storekeeper/** and sign in:
   - Admin: `admin` / `admin123`
   - Staff: `staff` / `staff123`
5. Change the passwords (top-right user icon → My account, or Staff Accounts) and delete `install.php`.

### Prefer phpMyAdmin?
Open http://localhost/phpmyadmin → **Import** → choose `database.sql` → **Go**.  
(That gives you empty tables + the two logins, without sample data.)

### Different MySQL password / port?
Edit `config.php` (`DB_USER`, `DB_PASS`, `DB_HOST`). XAMPP default is user `root`, empty password.

## What's inside

| Page | What it does |
|---|---|
| Dashboard | Today / month sales, profit, low-stock & expiry alerts, 7-day chart, top sellers |
| New Sale (POS) | Tap or search products (barcode scanners work – scan + Enter), qty, discount, tax, customer, payment method |
| Sales & Invoices | Search by date/invoice, printable invoice, admin can cancel a bill (stock restored) |
| Products / Categories | Full CRUD, SKU, units (kg, pack…), cost & selling price, reorder level, expiry date |
| Stock Control | Add/remove stock with a reason, restock list, full movement history |
| Stock In / Purchases | Receive supplier deliveries, adds stock and can update cost prices |
| Suppliers / Customers | Contact lists with purchase / spend totals |
| Reports | Revenue, profit, top products, category & payment split, day-by-day, CSV export |
| Staff Accounts / Settings | Admin only: users & roles, store name, currency, tax %, invoice footer |

Security basics included: hashed passwords, prepared SQL statements, CSRF tokens, role checks.

## Folder layout

```
storekeeper/
├── index.php  login.php  pos.php  products.php  ...   (pages)
├── includes/   db.php  functions.php                  (database + layout helpers)
├── assets/     css/style.css  js/app.js
├── config.php  database.sql  install.php
```

## Troubleshooting

- **"Database not ready"** → MySQL isn't started, or run `install.php` first.
- **Apache won't start** → port 80 is busy (Skype/IIS). Change `Listen 80` to `8080` in `httpd.conf`, then use `http://localhost:8080/storekeeper/`.
- **"Access denied for user"** → fix `DB_USER` / `DB_PASS` in `config.php`.
