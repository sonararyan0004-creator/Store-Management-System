<?php
require_once __DIR__ . '/includes/functions.php';
require_admin();

$me = current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['delete'])) {
        $uid = (int)$_POST['delete'];
        if ($uid === $me) {
            flash('error', 'You cannot delete your own account.');
        } else {
            q('DELETE FROM users WHERE id = ?', [$uid]);
            flash('success', 'Account deleted.');
        }
        redirect('users.php');
    }

    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $role = ($_POST['role'] ?? 'staff') === 'admin' ? 'admin' : 'staff';
    $pass = $_POST['password'] ?? '';

    if ($name === '' || $username === '') {
        flash('error', 'Name and username are required.');
        redirect('users.php' . ($id ? "?edit=$id" : ''));
    }
    if (val('SELECT COUNT(*) FROM users WHERE username = ? AND id <> ?', [$username, $id])) {
        flash('error', 'That username is already taken.');
        redirect('users.php' . ($id ? "?edit=$id" : ''));
    }
    if (!$id && strlen($pass) < 6) {
        flash('error', 'Password must be at least 6 characters.');
        redirect('users.php');
    }
    if ($id) {
        if ($id === $me) $role = 'admin'; // do not let admins lock themselves out
        q('UPDATE users SET name=?, username=?, role=? WHERE id=?', [$name, $username, $role, $id]);
        if ($pass !== '') {
            if (strlen($pass) < 6) { flash('error', 'Password must be at least 6 characters.'); redirect("users.php?edit=$id"); }
            q('UPDATE users SET password=? WHERE id=?', [password_hash($pass, PASSWORD_DEFAULT), $id]);
        }
        flash('success', 'Account updated.');
    } else {
        q('INSERT INTO users (name, username, password, role) VALUES (?,?,?,?)', [$name, $username, password_hash($pass, PASSWORD_DEFAULT), $role]);
        flash('success', 'Account created.');
    }
    redirect('users.php');
}

$edit = isset($_GET['edit']) ? row('SELECT id, name, username, role FROM users WHERE id = ?', [(int)$_GET['edit']]) : null;
$users = rows('SELECT u.*, (SELECT COUNT(*) FROM sales s WHERE s.user_id = u.id) bills FROM users u ORDER BY u.id');

page_header('Staff Accounts', 'users');
?>
<div class="split">
  <div class="card">
    <h3><?= $edit ? 'Edit account' : 'Add account' ?></h3>
    <form method="post" class="form" autocomplete="off">
      <?= csrf_field() ?>
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
      <label class="field"><span>Full name *</span><input name="name" value="<?= e($edit['name'] ?? '') ?>" required></label>
      <label class="field"><span>Username *</span><input name="username" value="<?= e($edit['username'] ?? '') ?>" required></label>
      <label class="field"><span><?= $edit ? 'New password (leave empty to keep)' : 'Password *' ?></span><input type="password" name="password" minlength="6" <?= $edit ? '' : 'required' ?> autocomplete="new-password"></label>
      <label class="field"><span>Role</span>
        <select name="role"><option value="staff" <?= ($edit['role'] ?? '') === 'staff' ? 'selected' : '' ?>>Staff (billing &amp; stock)</option><option value="admin" <?= ($edit['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin (everything)</option></select></label>
      <div class="actions"><button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Create account' ?></button><?php if ($edit): ?><a class="btn" href="users.php">Cancel</a><?php endif; ?></div>
    </form>
  </div>
  <div class="card">
    <h3>Accounts</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Name</th><th>Username</th><th>Role</th><th class="r">Bills</th><th class="r">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><b><?= e($u['name']) ?></b><?= (int)$u['id'] === $me ? ' <span class="badge badge-green">You</span>' : '' ?></td>
          <td><?= e($u['username']) ?></td>
          <td><span class="badge <?= $u['role'] === 'admin' ? 'badge-blue' : 'badge-green' ?>"><?= e(ucfirst($u['role'])) ?></span></td>
          <td class="r"><?= (int)$u['bills'] ?></td>
          <td class="r nowrap">
            <a class="btn btn-sm" href="users.php?edit=<?= (int)$u['id'] ?>" title="Edit"><?= icon('edit') ?></a>
            <?php if ((int)$u['id'] !== $me): ?>
            <form method="post" class="inline" data-confirm="Delete the account for <?= e($u['name']) ?>?">
              <?= csrf_field() ?><input type="hidden" name="delete" value="<?= (int)$u['id'] ?>">
              <button class="btn btn-sm btn-danger" title="Delete"><?= icon('trash') ?></button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</div>
<?php page_footer();
