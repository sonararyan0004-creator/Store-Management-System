<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$uid = current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $row = row('SELECT password FROM users WHERE id = ?', [$uid]);
    $new = $_POST['new_password'] ?? '';
    if (!$row || !password_verify($_POST['current_password'] ?? '', $row['password'])) {
        flash('error', 'Your current password is not correct.');
    } elseif (strlen($new) < 6) {
        flash('error', 'The new password must be at least 6 characters.');
    } elseif ($new !== ($_POST['confirm_password'] ?? '')) {
        flash('error', 'The new passwords do not match.');
    } else {
        q('UPDATE users SET password = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $uid]);
        flash('success', 'Password changed.');
    }
    redirect('profile.php');
}

$u = current_user();
page_header('My account', '');
?>
<div class="card" style="max-width:520px">
  <p><b><?= e($u['name']) ?></b> <span class="badge badge-blue"><?= e(ucfirst($u['role'])) ?></span><br><span class="muted">Username: <?= e($u['username']) ?></span></p>
  <h3 style="margin-top:20px">Change password</h3>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <label class="field"><span>Current password</span><input type="password" name="current_password" required autocomplete="current-password"></label>
    <label class="field"><span>New password</span><input type="password" name="new_password" minlength="6" required autocomplete="new-password"></label>
    <label class="field"><span>Confirm new password</span><input type="password" name="confirm_password" minlength="6" required autocomplete="new-password"></label>
    <div class="actions"><button class="btn btn-primary" type="submit">Update password</button></div>
  </form>
</div>
<?php page_footer();
