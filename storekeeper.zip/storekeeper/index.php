<?php
require_once __DIR__ . '/includes/functions.php';
require_login();

$today = date('Y-m-d');
$monthStart = date('Y-m-01');

$todaySales = row("SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM sales WHERE DATE(created_at) = ?", [$today]);
$monthSales = row("SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM sales WHERE DATE(created_at) >= ?", [$monthStart]);
$todayProfit = (float)val("SELECT COALESCE(SUM(si.total - si.qty * si.cost),0) FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE DATE(s.created_at) = ?", [$today]);
$productCount = (int)val('SELECT COUNT(*) FROM products');
$stockValue = (float)val('SELECT COALESCE(SUM(stock * cost_price),0) FROM products');
$lowCount = (int)val('SELECT COUNT(*) FROM products WHERE stock > 0 AND stock <= reorder_level');
$outCount = (int)val('SELECT COUNT(*) FROM products WHERE stock <= 0');
$alertDays = (int)setting('expiry_alert_days', '30');
$expiring = rows('SELECT id, name, stock, unit, expiry_date FROM products WHERE expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL ' . $alertDays . ' DAY) AND stock > 0 ORDER BY expiry_date LIMIT 6');
$lowList = rows('SELECT id, name, stock, unit, reorder_level FROM products WHERE stock <= reorder_level ORDER BY stock ASC LIMIT 8');

// last 7 days chart
$days = [];
for ($i = 6; $i >= 0; $i--) {
    $days[date('Y-m-d', strtotime("-$i day"))] = 0.0;
}
foreach (rows("SELECT DATE(created_at) d, SUM(total) t FROM sales WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(created_at)") as $r) {
    if (isset($days[$r['d']])) $days[$r['d']] = (float)$r['t'];
}
$max = max($days) ?: 1;

$top = rows("SELECT si.name, SUM(si.qty) q, SUM(si.total) t FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE s.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY si.name ORDER BY t DESC LIMIT 5");
$topMax = $top ? (float)$top[0]['t'] : 1;
$recent = rows("SELECT s.id, s.invoice_no, s.total, s.payment_method, s.created_at, c.name cname FROM sales s LEFT JOIN customers c ON c.id = s.customer_id ORDER BY s.id DESC LIMIT 6");

page_header('Dashboard', 'dashboard');
?>
<div class="grid g-4">
  <div class="card stat"><div class="bubble"><?= icon('rupee') ?></div><div><small>Today's sales</small><b><?= e(money($todaySales['t'])) ?></b><em><?= (int)$todaySales['c'] ?> bills · profit <?= e(money($todayProfit)) ?></em></div></div>
  <div class="card stat blue"><div class="bubble"><?= icon('chart') ?></div><div><small>This month</small><b><?= e(money($monthSales['t'])) ?></b><em><?= (int)$monthSales['c'] ?> bills</em></div></div>
  <div class="card stat"><div class="bubble"><?= icon('box') ?></div><div><small>Products</small><b><?= $productCount ?></b><em>Stock value <?= e(money($stockValue)) ?></em></div></div>
  <div class="card stat <?= ($lowCount + $outCount) ? 'amber' : '' ?>"><div class="bubble"><?= icon('alert') ?></div><div><small>Needs attention</small><b><?= $lowCount + $outCount ?></b><em><?= $lowCount ?> low · <?= $outCount ?> out of stock</em></div></div>
</div>

<div class="grid mt" style="grid-template-columns:2fr 1fr">
  <div class="card">
    <div class="card-head"><h3>Sales — last 7 days</h3><span class="muted">Total <?= e(money(array_sum($days))) ?></span></div>
    <div class="bars">
      <?php foreach ($days as $d => $t): ?>
        <div class="bar" title="<?= e(fdate($d) . ': ' . money($t)) ?>">
          <em><?= $t > 0 ? e(setting('currency', '₹') . number_format($t, 0)) : '' ?></em>
          <i style="height:<?= max(2, round($t / $max * 100)) ?>%"></i>
          <span><?= e(date('D d', strtotime($d))) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card">
    <h3>Top sellers (30 days)</h3>
    <?php foreach ($top as $t): ?>
      <div style="margin-bottom:12px">
        <div class="list-row" style="border:0;padding:0 0 4px"><span><?= e($t['name']) ?></span><b><?= e(money($t['t'])) ?></b></div>
        <div class="hbar"><i style="width:<?= round($t['t'] / $topMax * 100) ?>%"></i></div>
      </div>
    <?php endforeach; ?>
    <?php if (!$top): ?><p class="muted">No sales yet — make your first sale from the POS.</p><?php endif; ?>
  </div>
</div>

<div class="grid g-3 mt">
  <div class="card">
    <div class="card-head"><h3>Low / out of stock</h3><a href="stock.php">Manage</a></div>
    <?php foreach ($lowList as $p): ?>
      <div class="list-row"><span><?= e($p['name']) ?></span>
        <span><?= $p['stock'] <= 0 ? '<span class="badge badge-red">Out</span>' : '<span class="badge badge-amber">' . e(qty($p['stock'])) . ' ' . e($p['unit']) . '</span>' ?></span></div>
    <?php endforeach; ?>
    <?php if (!$lowList): ?><p class="muted">All items are well stocked 🎉</p><?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>Expiring soon</h3><span class="muted"><?= $alertDays ?> days</span></div>
    <?php foreach ($expiring as $p): ?>
      <div class="list-row"><span><?= e($p['name']) ?><br><small><?= e(qty($p['stock'])) ?> <?= e($p['unit']) ?> left</small></span><?= expiry_badge($p['expiry_date']) ?></div>
    <?php endforeach; ?>
    <?php if (!$expiring): ?><p class="muted">Nothing is close to expiry.</p><?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>Recent bills</h3><a href="sales.php">All sales</a></div>
    <?php foreach ($recent as $s): ?>
      <div class="list-row"><span><a href="invoice.php?id=<?= (int)$s['id'] ?>"><b><?= e($s['invoice_no']) ?></b></a><br><small><?= e($s['cname'] ?: 'Walk-in') ?> · <?= e(fdate($s['created_at'], 'd M, h:i A')) ?></small></span><b><?= e(money($s['total'])) ?></b></div>
    <?php endforeach; ?>
    <?php if (!$recent): ?><p class="muted">No bills yet.</p><?php endif; ?>
  </div>
</div>
<?php page_footer();
