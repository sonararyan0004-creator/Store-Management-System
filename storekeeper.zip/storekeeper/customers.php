<?php
require_once __DIR__ . '/includes/functions.php';

crud_page([
    'table' => 'customers',
    'title' => 'Customers',
    'singular' => 'Customer',
    'active' => 'customers',
    'fields' => [
        'name' => ['label' => 'Customer name', 'required' => true],
        'phone' => ['label' => 'Phone', 'type' => 'tel'],
        'email' => ['label' => 'Email', 'type' => 'email'],
        'address' => ['label' => 'Address'],
    ],
    'columns' => [
        'name' => ['Name'],
        'phone' => ['Phone'],
        'bills' => ['Bills', 'num'],
        'spent' => ['Total spent', 'money'],
    ],
    'list_sql' => 'SELECT c.*, (SELECT COUNT(*) FROM sales s WHERE s.customer_id = c.id) AS bills, (SELECT COALESCE(SUM(total),0) FROM sales s WHERE s.customer_id = c.id) AS spent FROM customers c ORDER BY c.name',
]);
